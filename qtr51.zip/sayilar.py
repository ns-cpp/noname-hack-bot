from Terminal.Modules import ChannelSwitcher
ChannelSwitcher.instance.sayi=4