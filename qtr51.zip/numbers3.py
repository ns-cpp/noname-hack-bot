import net

slotb=0
net.SendItemDropPacketNew(slotb,200)