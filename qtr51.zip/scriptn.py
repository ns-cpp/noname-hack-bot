from Terminal.Modules import FishingBot


FishingBot.instance.xrc=4
